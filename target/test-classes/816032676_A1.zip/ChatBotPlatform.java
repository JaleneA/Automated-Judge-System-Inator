import java.util.ArrayList;
/**
 * The ChatBotPlatform class manages one or more ChatBot objects within a bots collection. 
 * Accessors are required for all attributes.
 *
 * @author Jalene Armstrong - 816032676
 */
public class ChatBotPlatform {
    //Attributes
    private ArrayList<ChatBot> bots;
    
    //Constructor
    public ChatBotPlatform() {
        bots = new ArrayList<>();
    }
    
    //Accessors
    public ArrayList<ChatBot> getBots() {
        return bots;
    }
    
    //Mutators
    public boolean addChatBot(int LLMcode) {
        if (!(ChatBot.limitReached())) {
            ChatBot newChatBot = new ChatBot(LLMcode);
            bots.add(newChatBot);
            return true; //Successful
        }
        return false; //Otherwise
    }
    
    public String getChatBotList() {
        String chatBotList = "";
        int botNumber = 0;
        
        chatBotList += "---------------------\n";
        chatBotList += "Your ChatBots\n";
        
        //Bot Statistic Summary
        for (ChatBot chatBot : bots) {
            chatBotList += "Bot Number: " + (botNumber++) + "\t";
            chatBotList += "ChatBot Name: " + chatBot.getChatBotName() + "\t";
            chatBotList += "Number Messages Used: " + chatBot.getNumResponsesGenerated() + "\n";
        }
        
        //Totals Statistic Summary
        chatBotList += "Total Messages Used: " + ChatBot.getTotalNumResponsesGenerated() + "\n";
        chatBotList += "Total Messages Remaining: " + ChatBot.getTotalNumMessagesRemaining() + "\n";
        chatBotList += "---------------------";
        
        return chatBotList;
    }
    
    public String interactWithBot(int botNumber, String message) {
        if (botNumber < 0 || botNumber >= bots.size()) {
            return ("Incorrect Bot Number (" + botNumber + ") Selected. Try Again.");
        }
        else {
            ChatBot choosenBot = bots.get(botNumber);
            return (choosenBot.prompt(message));
        }
    }
}
/**
 * Helpful Documentation:
 * | 1.ArrayList Handout
 * (Source: COMP2603-Object-Oriented Programming I Course Documentation)
 * 
 */