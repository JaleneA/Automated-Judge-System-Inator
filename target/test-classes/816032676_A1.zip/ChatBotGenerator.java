/**
 * The ChatBotGenerator class models the generation of various LLMs. 
 * Disclaimer: No actual LLMs are used in this simulation.
 * 
 * @author Jalene Armstrong - 816032676
 */
public class ChatBotGenerator {    
    public static String generateChatBotLLM(int LLMCodeNumber) {
        String botName = "ChatGPT-3.5"; //Default
         switch (LLMCodeNumber) {
            case 1:
                return (botName = "LLaMa");
            case 2:
                return (botName = "Mistral7B");
            case 3:
                return (botName = "Bard");
            case 4:
                return (botName = "Claude");
            case 5:
                return (botName = "Solar");
        }
        return botName; //ChatGPT-3.5
    }
}
/**
 * Helpful Documentation:
 * | 1.Week 2:Lecture 1
 * (Source: COMP2603-Object-Oriented Programming I Course Documentation)
 */
