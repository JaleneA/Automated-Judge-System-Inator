import java.util.Scanner;
/**
 * This class contains the main method for your solution.
 * It should do the following programmatically:
 * 1. Begin with a Hello World! printed to the screen.
 * 2. Declare and initialise a ChatBotPlatform object.
 * 3. Add several ChatBot objects (at least one of each kind) to the ChatBotPlatform.
 * 4. Print out on the screen the list of all ChatBots managed by the ChatBotPlatform with their summary statistics.
 * 5. Interact up to 15 times with random ChatBots by sending messages, printing out their responses to the screen
 * 6. Print out on the screen a final list of all ChatBots managed by the ChatBotPlatform with their summary statistics.
 *
 * @author Jalene Armstrong - 816032676
 */
public class ChatBotSimulation
{
    public static void main (String[] args) {
        System.out.println("Hello World!"); // #1
        ChatBotPlatform chatBotPlatform = new ChatBotPlatform(); // #2
        
        // #3
        for (int i = 0; i <= 6; i++) {
            chatBotPlatform.addChatBot(i);
        }
        
        // #4
        String chatBotList = chatBotPlatform.getChatBotList();
        System.out.println(chatBotList);
        
        // #5
        for (int i = 0; i < 15; i++) {
            java.util.Random r = new java.util.Random();
            int randNum = r.nextInt(8);            
            String botInteraction = chatBotPlatform.interactWithBot(randNum, "This Assignment Was Fun :D");
            
             if (botInteraction.startsWith("Incorrect")) {
                    i--; //Doesn't Count As An Interaction
                }
            
            System.out.println(botInteraction);
        }
        
        // #6
        String finalChatBotList = chatBotPlatform.getChatBotList();
        System.out.println(finalChatBotList);
    }
}
/**
 * Helpful Documentation:
 * | 1.Java main() Method
 * (Source: https://www.javatpoint.com/java-main-method)
 * 
 * | 2.Week2:Lecture1
 * (Source: COMP2603-Object-Oriented Programming I Course Documentation)
 * 
 * | 3.Week1:Lab1 & Week2:Lab2 
 * (Source: COMP2603-Object-Oriented Programming I Course Documentation)
 */
