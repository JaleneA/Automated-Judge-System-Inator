/**
 * The ChatBot class models chatbot that accepts a user message 
 * and generates a response up to a maximum daily limit.
 *
 * @author Jalene Armstrong - 816032676
 */
public class ChatBot {
    //Attributes
    private String chatBotName;
    private int numResponsesGenerated;
    private static final int messageLimit = 10;
    private static int messageNumber = 0;
 
    //Constructor
    public ChatBot() {
        this.chatBotName = ChatBotGenerator.generateChatBotLLM(0);
    }
    
    //Overloaded Constructor
    public ChatBot(int LLMCode) { 
        this.chatBotName = ChatBotGenerator.generateChatBotLLM(LLMCode);
    }
    
    //Accessors 
    public String getChatBotName() {
        return this.chatBotName;
    }
    public int getNumResponsesGenerated() {
        return this.numResponsesGenerated;
    }
    public static int getTotalNumResponsesGenerated() {
        return messageNumber;
    }
    public int getMessageLimit() {
        return this.messageLimit;
    }
    public static int getTotalNumMessagesRemaining() {
        return (messageLimit - messageNumber);
    }
    
    public static boolean limitReached() {
        if (messageNumber == messageLimit) {
            return true;
        }
        return false;
    }

    //Mutators
    private String generateResponse() {
        numResponsesGenerated++;
        return (
            "(Message #" + (++messageNumber) + ") Response from " + getChatBotName() +
            " >> " + "generatedTextHere"
        );
    }

    public String prompt(String requestMessage) {
        if (!(limitReached())) {
            return(this.generateResponse());
        }
        return("Daily Limit Reached. Wait 24 hours to resume chatbot usage.");
    }
    
    //toString
    public String toString() {
        return(
            "ChatBot Name: " + getChatBotName() + "     " +
            "Number Messages Used: " + getNumResponsesGenerated() + "\n"
        );
    }
}
/**
 * Helpful Documentation:
 * | 1.Class Methods in Java - SyntaxDB - Java Syntax Reference
 * (Source: https://syntaxdb.com/ref/java/class-methods)
 * 
 * | 2.Defining Methods
 * (Source: https://dev.java/learn/classes-objects/defining-methods/)
 * 
 * | 3.Class Methods vs Instance Methods in Java
 * (Source: https://www.baeldung.com/java-class-methods-vs-instance-methods)
 * 
 * | 4.A Guide to the Static Keyword in Java
 *  (Source: https://www.baeldung.com/java-static)
 *  
 * | 5.Final Keyword in Java
 *  (Source: https://www.javatpoint.com/final-keyword)
 */
